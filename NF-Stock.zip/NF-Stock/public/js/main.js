$(document).ready(function(){
    $('.phone').mask('(00)0000-0000#0');
    $('.cpf').mask('000000000-00');
    $('.data_validade').mask('00/0000');
    $(".clickmenu").click(function () {
        var valor = $(this).data('val');
        $("#tabsmodal li").each(function () {
            $(this).removeClass('active');
            $('#tabsmodal .li-'+valor).addClass('active');
        });
        $(".tab-content .tab-pane").each(function () {
            $(this).removeClass('in active');
        });
        $(".tab-content #"+valor).addClass('in active');
    });
    $(".click-plano").click(function () {
        var nome = $(this).data('nome');
        var id = $(this).data('id');
        var valor = $(this).data('valor');

        $("#plano-texto").html(nome);
        $("#id-plano").val(id);
        $("#plano-valor").html(valor);
    });
});