<template>
    <div class="banner">
        <div class="painel">
            <div class="texto">
                <h2>Tenha seu Escritório Contábil na Nuvem * com facilidade e segurança</h2>
                <h3>Chega de ligar várias vezes para seus clientes cobrando as notas eletrônicas. O NF-Stock Alterdata faz a importação automática de todas as notas recebidas por seus clientes direto do site da Receita Federal, utilizando o certificado digital.</h3>
                <a href="#contato">Entrar em contato</a>
            </div>
        </div>
        <div class="mascara"></div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
