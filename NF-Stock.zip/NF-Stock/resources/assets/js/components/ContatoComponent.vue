<template>
    <div class="contato" id="contato">
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-5 col-md-6">
                    <div class="col-xs-12">
                        <h2>Entre em contato com a Alterdata
                            e solicite uma demonstração</h2>
                        <p>
                            Junte-se aos mais de 500 mil usuários
                        </p>
                        <p class="telefonetxt">Quero falar com o Comercial
                            <a href="tel:0800 704 1418" class="telefone">
                                0800-704-1418.
                            </a>
                        </p>
                    </div>
                </div>
                <div class="col-lg-offset-5 col-md-6">
                    <div class="col-xs-12">
                        <h3>Falar com vendas?
                            Nós te ligamos.</h3>
                    </div>
                    <form method="post" action="#">
                        <div class="form-group col-sm-6">
                            <input type="tel" class="form-control phone" placeholder="Digite seu telefone (ddd+numero)" name="telefone" id="telefone"/>
                        </div>
                        <div class="form-group col-sm-6">
                            <button type="button">AGENDAR AGORA</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
