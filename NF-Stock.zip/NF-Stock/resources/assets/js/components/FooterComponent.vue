<template>
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <h4>O NF-STOCK</h4>
                    <p>
                        É um sistema 100% web capaz de buscar, gerenciar e armazenar documentos fiscais de diversos modelos, utilizando o melhor da tecnologia em nuvem contando com armazenamento em nossos servidores pelo prazo legal, otimizando a sua Escrita Fiscal com integração automática com o Fiscal Alterdata.
                    </p>
                </div>
                <div class="col-sm-4">
                    <h4>O que entregamos</h4>
                    <ul>
                        <li>Produtividade e Segurança</li>
                        <li>Tecnologia</li>
                        <li>Produtividade</li>
                        <li>Segurança</li>

                    </ul>
                </div>
                <div class="col-sm-4">
                    <p>
                        O Alterdata Pack importa os dados e lança a nota no Escrita Fiscal. Você será notificado da importação através do Gerente Eletrônico Alterdata. É possível visualizar e fazer o download do XML ou da DANFE sempre que precisar.
                    </p>
                </div>
            </div>
        </div>
    </footer>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
