@extends('layouts.app')

@section('content')
    <div id="home">

        <div class="planos">
            <div class="container" >
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <h1>Planos e Preços</h1>
                    </div>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <div class="painel-planos">
                            <div class="header">
                                Plano 15 mil notas
                            </div>
                            <div class="main">
                                <p>R$24,99</p>
                            </div>
                            <div class="footer">
                                <button type="button" class="click-plano" data-valor="24,99" data-id="1" data-nome="Plano 15 mil notas" data-toggle="modal" data-target="#modalPlano">ASSINE JÁ</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <div class="painel-planos azul">
                            <div class="header">
                                Plano 45 mil notas
                            </div>
                            <div class="main">
                                <p>R$40,99</p>
                            </div>
                            <div class="footer">
                                <button type="button" class="click-plano" data-valor="40,99" data-id="2" data-nome="Plano 45 mil notas" data-toggle="modal" data-target="#modalPlano">ASSINE JÁ</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-4 col-md-4">
                        <div class="painel-planos">
                            <div class="header">
                                Plano ilimitado
                            </div>
                            <div class="main">
                                <p>R$69,99</p>
                            </div>
                            <div class="footer">
                                <button type="button" class="click-plano" data-valor="69,99" data-id="3" data-nome="Plano ilimitado" data-toggle="modal" data-target="#modalPlano">ASSINE JÁ</button>
                            </div>
                        </div>
                    </div>

                    <div id="modalPlano" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title"><span  id="plano-texto"></span> - R$<span id="plano-valor"></span></h4>
                                </div>
                                <div class="modal-body">
                                    <form class="formlogincad" method="post" action="#">
                                        <div class="form-group col-xs-8">
                                            <label>Número do cartão:</label>
                                            <input type="text" class="form-control" placeholder="Número do cartão" name="numero_cartao" id="numero_cartao" required>
                                        </div>
                                        <div class="form-group col-xs-4">
                                            <label>Data de validade:</label>
                                            <input type="text" class="form-control data_validade" placeholder="Data de validade" name="data_validade" id="data_validade" required>
                                        </div>
                                        <div class="form-group col-xs-6">
                                            <label>Nome do dono do cartão:</label>
                                            <input type="text" class="form-control" placeholder="Nome do dono do cartão" name="nome_cartao" id="nome_cartao" required>
                                        </div>
                                        <div class="form-group col-xs-6">
                                            <label>Código de segurança:</label>
                                            <input type="text" class="form-control" placeholder="Codigo de segurança" name="codigo_seguranca" id="codigo_seguranca" required>
                                        </div>
                                        <div class="form-group col-xs-12">
                                            <input type="hidden" id="id-plano">
                                            <button type="submit">ENTRAR</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="produtividade fundowhite">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h2>Produtividade e Segurança</h2>
                        <p>
                            O NF-Stock é um sistema 100% web capaz de buscar, gerenciar e armazenar documentos fiscais de diversos modelos, utilizando o melhor da tecnologia em nuvem contando com armazenamento em nossos servidores pelo prazo legal, otimizando a sua Escrita Fiscal com integração automática com o Fiscal Alterdata.
                        </p>
                        <button>
                            SOLICITE UMA DEMOSTRAÇÂO
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="imagem-texto fundowhite">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="center">
                            <img src="{{asset("/storage/nfstock_ilustra.svg")}}" alt="Tecnologia">
                        </div>
                    </div>
                    <div class="col-sm-9">
                        <h3>TECNOLOGIA</h3>
                        <p>
                            Chega de ligar várias vezes para seus clientes cobrando as notas eletrônicas. O NF-Stock Alterdata faz a importação automática de todas as notas recebidas por seus clientes direto do site da Receita Federal, utilizando o certificado digital.
                        </p>
                        <p>
                            Além de importar as notas de seus clientes, o NF-Stock é uma ferramenta que armazena as NF-es/CT-es recebidas e emitidas por seis anos com toda segurança e praticidade. Acabe com a digitação de notas fiscais eletrônicas!
                        </p>
                        <p>
                            E as notas emitidas pelo cliente? Ele pode enviá-las por e-mail ou instalar um aplicativo desktop. Toda vez que uma nova nota fiscal for emitida pela empresa, o sistema envia para o NF-Stock e as notas armazenadas serão importadas pelo Escrita Fiscal.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="imagem-texto">
            <div class="container">
                <div class="row">
                    <div class="col-sm-9">
                        <h3>PRODUTIVIDADE</h3>
                        <p>
                            O Alterdata Pack importa os dados e lança a nota no Escrita Fiscal. Você será notificado da importação através do Gerente Eletrônico Alterdata. É possível visualizar e fazer o download do XML ou da DANFE sempre que precisar.
                        </p>
                        <p>
                            Você pode enviar as notas fiscais eletrônicas por e-mail ou pelo Pack UP Alterdata para seus clientes sempre que precisar. Seu cliente também pode acessá-las diretamente no site.
                        </p>
                        <p>
                            Organize automaticamente os documentos fiscais, direcionando os XMLs recebidos e emitidos para cada cliente do escritório. Segurança na organização dos documentos fiscais, sem necessidade de intervenção manual.
                        </p>
                        <p>
                            Busca rápida de documentos fiscais, com diferentes filtros para localização de notas fiscais e conhecimentos de transporte sem complicação, entre eles: número da nota, chave de acesso, emitente, fornecedor, data de emissão, status e tipo.
                        </p>
                    </div>
                    <div class="col-sm-3">
                        <div class="center">
                            <img src="{{asset('/storage/gear.svg')}}" alt="Produtividade">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="imagem-texto fundowhite">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <h3><img src="{{asset('/storage/seguranca.svg')}}" width="40" alt="Segurança"> SEGURANÇA</h3>
                        <p>
                            O NF-Stock protege seu cliente contra fraudes! Todas as notas emitidas contra o CNPJ do seu cliente serão automaticamente baixadas do site da Receita Federal ou da Prefeitura, evitando que as notas geradas indevidamente passem despercebidas. Além disso, todos os arquivos DANFE recebidos junto com a mercadoria podem ser comparados com os arquivos XML disponíveis no NF-Stock, assim o produto não será recebido com documentos falsificados. É possível, inclusive, manifestar as notas diretamente no sistema.
                        </p>
                        <p>
                            Para os documentos de saída, tenha também o controle de NF-e faltante, facilitando as auditorias. Canceladas e inutilizadas também podem ser gerenciadas.
                        </p>
                        <p>
                            Defina o tempo de armazenamento dos documentos fiscais de cada cliente!
                        </p>
                        <p>
                            Com liberdade para downloads e visualizações, o seu cliente também terá um usuário próprio para acesso web ao sistema e pode baixar e visualizar os arquivos XML e DANFE (pdf) sempre que precisar, diretamente no NF-Stock. Isso significa para o cliente visão e gerenciamento do seu próprio negócio, além da comodidade de ter todas estas informações disponíveis a qualquer momento.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <contato-componet></contato-componet>
@endsection
