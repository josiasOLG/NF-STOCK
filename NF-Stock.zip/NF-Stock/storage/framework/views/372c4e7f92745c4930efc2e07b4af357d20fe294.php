<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>

<div id="app">
    <menu-component></menu-component>
    <div id="modalMenu" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <ul class="nav nav-tabs" id="tabsmodal">
                        <li class="active li-login">
                            <a data-toggle="tab" href="#login">LOGIN</a>
                        </li>
                        <li class="li-cadastrar">
                            <a data-toggle="tab" href="#cadastrar">CADASTRAR</a>
                        </li>
                    </ul>
                </div>
                <div class="modal-body">
                    <div class="tab-content">
                        <div id="login" class="tab-pane fade in active">
                            <form class="formlogincad" method="post" action="#">
                                <div class="form-group">
                                    <label>Digite seu email:</label>
                                    <input type="email" class="form-control" placeholder="Digite seu email" name="email" id="email" required>
                                </div>
                                <div class="form-group">
                                    <label>Digite sua senha:</label>
                                    <input type="password" class="form-control" placeholder="Digite sua senha" name="senha" id="senha" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit">ENTRAR</button>
                                </div>
                            </form>
                        </div>
                        <div id="cadastrar" class="tab-pane fade">
                            <form class="formlogincad" method="post" action="#">
                                <div class="form-group">
                                    <label>Digite seu email:</label>
                                    <input type="email" class="form-control" placeholder="Digite seu email" name="email" id="email" required>
                                </div>
                                <div class="form-group">
                                    <label>Telefone:</label>
                                    <input type="tel" class="form-control phone" placeholder="Telefone (DDD+NÚMERO)" name="telefone" id="telefone" required>
                                </div>
                                <div class="form-group">
                                    <label>CPF:</label>
                                    <input type="text" class="form-control cpf" placeholder="Digite seu CPF" name="cpf" id="cpf" required>
                                </div>
                                <div class="form-group">
                                    <label>Digite sua senha:</label>
                                    <input type="password" class="form-control" placeholder="Digite sua senha" name="senha" id="senha" required>
                                </div>
                                <div class="form-group">
                                    <label>Confirmar senha:</label>
                                    <input type="password" class="form-control" placeholder="Confirmar senha" name="senha-conf" id="senha-conf" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit">CADASTRAR</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <banner-component></banner-component>
        <?php echo $__env->yieldContent('content'); ?>
    <footer-component></footer-component>
</div>


<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.mask.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        $('.phone').mask('(00)0000-0000#0');
        $('.cpf').mask('000000000-00');
        $(".clickmenu").click(function () {
           var valor = $(this).data('val');
          $("#tabsmodal li").each(function () {
              $(this).removeClass('active');
              $('#tabsmodal .li-'+valor).addClass('active');
          });
          $(".tab-content .tab-pane").each(function () {
              $(this).removeClass('in active');
          });
          $(".tab-content #"+valor).addClass('in active');
        });

        $(".click-plano").click(function () {
           var nome = $(this).data('nome');
           var id = $(this).data('id');
           var valor = $(this).data('valor');

           $("#plano-texto").html(nome);
           $("#id-plano").val(id);
           $("#plano-valor").html(valor);
        });
    });
</script>
</body>
</html>
